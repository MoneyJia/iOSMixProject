//
//  CppBase.cpp
//  confuse_test
//
//  Created by yjs on 2020/11/10.
//  Copyright © 2020 coding520. All rights reserved.
//

#include "CppBase.h"

void CppBase::private_sf1() {
    
}

void CppBase::static_private_sf1() {
    
}

void CppBase::protected_sf1() {
    
}

void CppBase::static_protected_sf1() {
    
}

void CppBase::sf1() {
    
}

void CppBase::sf1(int v) {
    
}

void CppBase::sf1(int *v) {
    
}

//void CppBase::sf1(int *v1, float v2){
//    
//}

int CppBase::sf1(int *v1, float *v2) {
    return *v1;
}

int* CppBase::sf1(int *v1, int *v2) {
    return v1;
}

void CppBase::static_sf1() {
    
}

char* CppBase::sf3() const {
    return m_name;
}

void CppBase::test() {
    
}
