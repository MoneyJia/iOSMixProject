//
//  Header.h
//  ipa
//
//  Created by yjs on 2020/2/6.
//  Copyright © 2020 yjs. All rights reserved.
//

#ifndef Header_h
#define Header_h

#include <string>
#include <iostream>
using namespace std;

#define Function_Log printf("%s\n", __FUNCTION__);

#endif /* Header_h */
