//
//  Dog_M.h
//  confuse_test
//
//  Created by yjs on 2020/9/9.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Dog_M : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *weight;

@end

NS_ASSUME_NONNULL_END
