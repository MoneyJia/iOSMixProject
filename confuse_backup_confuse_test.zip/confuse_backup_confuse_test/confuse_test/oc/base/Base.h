//
//  Base.h
//  confuse_test
//
//  Created by yjs on 2020/9/9.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Base <NSObject>

- (void)begin;

@end

@interface Base : NSObject

@end

NS_ASSUME_NONNULL_END
