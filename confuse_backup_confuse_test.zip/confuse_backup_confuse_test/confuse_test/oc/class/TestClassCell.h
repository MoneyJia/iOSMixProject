//
//  TestClassCell.h
//  confuse_test
//
//  Created by yjs on 2020/11/14.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestClassCell : UITableViewCell

@end

@protocol OcFileDataProtocol <NSObject>

@end

@interface LBHomeMatchUserTotalModel : NSObject<OcFileDataProtocol>

@end

NS_ASSUME_NONNULL_END
