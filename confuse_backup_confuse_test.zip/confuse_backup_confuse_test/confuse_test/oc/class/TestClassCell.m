//
//  TestClassCell.m
//  confuse_test
//
//  Created by yjs on 2020/11/14.
//  Copyright © 2020 coding520. All rights reserved.
//

#import "TestClassCell.h"

@implementation TestClassCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

@implementation LBHomeMatchUserTotalModel

@end
