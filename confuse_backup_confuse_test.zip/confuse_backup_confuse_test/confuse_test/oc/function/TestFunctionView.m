//
//  TestFunctionView.m
//  confuse_test
//
//  Created by yjs on 2021/3/1.
//  Copyright © 2021 coding520. All rights reserved.
//

#import "TestFunctionView.h"

@implementation TestFunctionView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

@implementation TestFunctionButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
