//
//  TestFrame.h
//  confuse_test
//
//  Created by ymac on 12/10/2020.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestFrame : NSObject


@property (nonatomic, assign) CGFloat width;


@end

NS_ASSUME_NONNULL_END
