//
//  TestMasonry.h
//  confuse_test
//
//  Created by ymac on 13/10/2020.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestMasonry : NSObject

@property (nonatomic, strong) UIView *view;
@property (nonatomic, strong) UILabel *label;

@end

NS_ASSUME_NONNULL_END
