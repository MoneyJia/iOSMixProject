//
//  TestMacro.m
//  confuse_test
//
//  Created by yjs on 2020/9/25.
//  Copyright © 2020 coding520. All rights reserved.
//

#import "TestMacro.h"

@implementation TestMacro

- (void)TEST_macro {
    
}

- (void)TEST_macro_(YJS) {
    
}

@end

#import <MJExtension/MJFoundation.h>

@implementation TestMacro2

- (void)TEST_macro {
    
}

- (void)TEST_macro_(YJS) {
    
}

@end
