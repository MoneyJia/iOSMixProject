//
//  TestOtherMacro.h
//  confuse_test
//
//  Created by yjs on 2020/9/26.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TestSuperMacro.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestOtherMacro : NSObject


- (void)TEST_super_macro1;
- (void)TEST_super_macro1_(YJS);

@end

NS_ASSUME_NONNULL_END
