//
//  TestOtherMacro.m
//  confuse_test
//
//  Created by yjs on 2020/9/26.
//  Copyright © 2020 coding520. All rights reserved.
//

#import "TestOtherMacro.h"

@implementation TestOtherMacro

- (void)TEST_super_macro1 {
    
}

- (void)TEST_super_macro1_(YJS) {
    
}

@end
