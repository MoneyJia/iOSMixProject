//
//  TestSuperMacro.m
//  confuse_test
//
//  Created by yjs on 2020/9/26.
//  Copyright © 2020 coding520. All rights reserved.
//

#import "TestSuperMacro.h"

@implementation TestSuperMacro

- (void)TEST_super_macro {
    YJS_TARGET;
}

- (void)TEST_super_macro_(YJS) {
    
}

@end
