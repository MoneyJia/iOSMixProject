//
//  TestImageModel.h
//  confuse_test
//
//  Created by yjs on 2020/11/2.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestImageModel : NSObject

@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *title;

@end

NS_ASSUME_NONNULL_END
