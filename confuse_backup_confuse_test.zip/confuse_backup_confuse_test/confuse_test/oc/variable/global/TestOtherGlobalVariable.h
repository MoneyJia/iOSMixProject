//
//  TestOtherGlobalVariable.h
//  confuse_test
//
//  Created by yjs on 2020/9/27.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const kSuperGlobalVariable1;

NS_ASSUME_NONNULL_BEGIN

@interface TestOtherGlobalVariable : NSObject

@end

NS_ASSUME_NONNULL_END
