//
//  TestLocalVariableTableViewController.h
//  confuse_test
//
//  Created by yjs on 2020/10/10.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestLocalVariableTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
