//
//  TestXibView.h
//  confuse_test
//
//  Created by ymac on 15/09/2020.
//  Copyright © 2020 coding520. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestXibView : UIView

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *home;

@end

NS_ASSUME_NONNULL_END
