//
//  SwiftTableViewController.swift
//  confuse_test
//
//  Created by yjs on 2021/1/28.
//  Copyright © 2021 coding520. All rights reserved.
//

import UIKit

class SwiftTableViewController: UITableViewController {
   
}
