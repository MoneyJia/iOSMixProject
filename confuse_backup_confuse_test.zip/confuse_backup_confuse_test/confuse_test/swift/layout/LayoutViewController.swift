//
//  LayoutViewController.swift
//  confuse_test
//
//  Created by yjs on 2021/11/9.
//  Copyright © 2021 coding520. All rights reserved.
//

import UIKit

class LayoutViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
