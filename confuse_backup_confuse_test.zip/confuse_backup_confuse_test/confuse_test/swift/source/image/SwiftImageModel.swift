//
//  SwiftImageModel.swift
//  confuse_test
//
//  Created by yjs on 2021/6/21.
//  Copyright © 2021 coding520. All rights reserved.
//

import Foundation

class SwiftImageModel {
    var title = ""
    var image = ""
}
