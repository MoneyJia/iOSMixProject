//
//  AppDelegate.h
//  ProjectFixDemo
//
//  Created by Journey on 2018/3/29.
//  Copyright © 2018年 Journey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

