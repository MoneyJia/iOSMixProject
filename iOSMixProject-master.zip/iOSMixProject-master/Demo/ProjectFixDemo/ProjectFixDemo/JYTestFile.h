//
//  JYTestFile.h
//  ProjectFixDemo
//
//  Created by Journey on 2018/3/29.
//  Copyright © 2018年 Journey. All rights reserved.
//



///JY就是类前缀，也是文件的前缀

#import <Foundation/Foundation.h>

@interface JYTestFile : NSObject

@end
